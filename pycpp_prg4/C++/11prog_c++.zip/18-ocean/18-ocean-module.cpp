//
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 4 (11 �����)
// ��������� � 17. ������ �����
//                 

#include "TXLib.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "ocean.hpp"

using namespace std;

int randInt( int a, int b ) {
  return a + rand() % (b-a+1);  
  }

int getMouseX() { return txMouseX(); }
int getMouseY() { return txMouseY(); }

void drawCircle( int x, int y, int r, 
                 COLORREF fillColor )
  {
  txSetColor( RGB(0,0,0) );          
  txSetFillColor( fillColor );               
  txCircle( x, y, r );  
  }  

void drawObject( int x, int y, int r, 
                 objectType type )
  {
  if( type == STONE ) 
    drawCircle( x, y, r, RGB(0,0,0) ); 
  else if( type == GRASS ) 
    drawCircle( x, y, r, RGB(0,255,0) ); 
  else if( type == FISH ) 
    drawCircle( x, y, r, RGB(0,0,255) ); 
  else /* if( type == HUNTER ) */
    drawCircle( x, y, r, RGB(255,0,0) ); 
  }      

int main()
  {
  srand( time(0) );	
  	
  COcean ocean;
  
  const int NUMBER_OF_STONES = 10;  
  for( int i = 0; i < NUMBER_OF_STONES; i++ ) 
    ocean.addObject ( STONE, randInt(0, SCREEN_WIDTH), randInt(0, SCREEN_HEIGHT), 
                             randInt(5, 15) );   

  const int NUMBER_OF_GRASS = 10;
  for( int i = 0; i < NUMBER_OF_GRASS; i++ ) 
    ocean.addObject ( GRASS, randInt(0, SCREEN_WIDTH), randInt(0, SCREEN_HEIGHT), 
                             randInt(5, 15) );   

  const int NUMBER_OF_FISH = 10;
  for( int i = 0; i < NUMBER_OF_FISH; i++ ) 
    ocean.addObject ( FISH, randInt(0, SCREEN_WIDTH), randInt(0, SCREEN_HEIGHT), 
					        5, 2, randInt(0, 360) );   

  ocean.addObject ( HUNTER, 100, 150, 10, 5 );  
  
  txCreateWindow( SCREEN_WIDTH, SCREEN_HEIGHT );
  
  while( not GetAsyncKeyState(VK_ESCAPE) )  {
    txSetFillColor( TX_WHITE );
    txClear();             
    ocean.update();
	txSleep( 50 );        
    }
       
  }    



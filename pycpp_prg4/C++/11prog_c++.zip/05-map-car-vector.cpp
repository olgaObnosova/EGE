//
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 4 (11 �����)
// ��������� � 5. �������� ������� ������
//                ������������� vector.

#include "TXLib.h"
#include <iostream>

using namespace std;

enum cellType { EMPTY, SIDE, WALL };                     

const int CELL_SIZE = 20;   

class CMap 
  {
  public:    
    int width, height;
    vector<vector<cellType>> cells;
    CMap( int width0 = 10, int height0 = 15 ); // ����������� � �����������
	void init();
    bool isFree( int x, int y ) const { 
      return cells[x][y] == EMPTY;
      }
	void show() const;  
  }; 

CMap::CMap( int width0, int height0 )
  {
  width = max( 0, width0 );
  height = max( 0, height0 );
  cells.resize(width);
  for( int i = 0; i < width; i++ )
    cells[i].resize(height); 
  init();
  }                   

void CMap::init()  
  {
  for( int x = 0; x < width; x++ )      
    for( int y = 0; y < height; y++ )      
      if( x == 0  or  x == width-1 ) 
           cells[x][y] = SIDE;
      else cells[x][y] = EMPTY; 
  } 
  
COLORREF cellColor( cellType type ) 
  {
  COLORREF color;
  if( type == EMPTY )  
    color = RGB(50, 255, 50);
  else if( type == SIDE )
    color = RGB(80, 0, 0); 
  else if( type == WALL )
    color = RGB(0, 80, 0); 
  return color;
  }
   
void drawCell( int x, int y, cellType type )
  {
  COLORREF color = cellColor( type );   
  txSetColor( color );
  txSetFillColor( color );
  int left = x*CELL_SIZE,
      top = y*CELL_SIZE;      
  txRectangle( left, top, 
      left+CELL_SIZE, top+CELL_SIZE );
  }

void CMap::show() const 
  {
  for( int x = 0; x < width; x++ )      
    for( int y = 0; y < height; y++ )      
      drawCell( x, y, cells[x][y] );  
  }  

class CCar 
  {
  public:
    CMap& map;                           
    int x, y;                              
    CCar( CMap& map0, int x0 = 0, int y0 = 0  ):
          map(map0), x(x0), y(y0)  {}
    void show();                           
    bool moveBy( int dx = 0, int dy = 0 ); 
  };    

void CCar::show()
  {  	
  COLORREF color = RGB(0, 0, 255);   
  txSetColor( color );
  txSetFillColor( color );
  int xCenter = x*CELL_SIZE + CELL_SIZE / 2,
      yCenter = y*CELL_SIZE + CELL_SIZE / 2;      
  POINT car[] = { {xCenter-5,yCenter}, {xCenter,yCenter-10}, 
                  {xCenter+5,yCenter}, {xCenter,yCenter+10}};    
  txPolygon( car, 4 );
  }

bool CCar::moveBy( int dx, int dy )
  {
  if( map.isFree( x+dx, y+dy ) ) { // (1)
    x += dx;
    y += dy;
    return true;
    }    
  else
    return false;   
  }

int main()
  {
  const int W = 15, L = 20;     
  CMap map( W, L );           
  CCar car( map, 10, 10 );
  
  txCreateWindow(W*CELL_SIZE, L*CELL_SIZE); 
  
  txBegin();
  while( not GetAsyncKeyState(VK_ESCAPE) ) { 
    txClear();                          
    if( GetAsyncKeyState(VK_LEFT) )     
      car.moveBy( -1 );         
    if( GetAsyncKeyState(VK_RIGHT) )    
      car.moveBy( 1 );
    map.show();                        
    car.show();                         
    txSleep(50);                        
    }
  txEnd();  
  
  }    



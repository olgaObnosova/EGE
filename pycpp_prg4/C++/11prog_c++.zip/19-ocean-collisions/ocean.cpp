// ������ � ��������
// 
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 4 (11 �����)
// ��������� � 19. ������ �����. ������������
//                 

#include "ocean.hpp"

#define M_PI		3.14159265358979323846

bool COceanObject::hasCollisionWith( COceanObject* pOther ) const
  {
  double distance = hypot( x - pOther->x, 
                           y - pOther->y );      
  return (distance < r + pOther->r);
  }

void CMovingObject::move()
  {
  double courseRadians = course*M_PI/180;

  x += round(v*cos(courseRadians));         
  y -= round(v*sin(courseRadians));

  if( x-r < 0 ) x += SCREEN_WIDTH;        
  if( x+r > SCREEN_WIDTH ) 
    x -= SCREEN_WIDTH;        

  if( y-r < 0 ) y += SCREEN_HEIGHT;        
  if( y+r > SCREEN_HEIGHT ) 
    y -= SCREEN_HEIGHT;        
  } 
 
void CFish::collideWith( COceanObject* pOther ) 
  { 
  // CHunter* pHunter = dynamic_cast <CHunter*> (pOther);
  auto pHunter = dynamic_cast <CHunter*> (pOther);
  if( pHunter ) r = 0;
  }  
 
int getMouseX();
int getMouseY();
void CHunter::change() 
  {
  int xMouse = getMouseX(), 
      yMouse = getMouseY(); 
  double dist = hypot(x - xMouse, 
                      y - yMouse);           
  if( dist < 1 ) return;
  double part = v / dist;
  if( part > 1 ) part = 1;
  x += round(part*(xMouse - x));
  y += round(part*(yMouse - y));
  }

void CHunter::collideWith( COceanObject* pOther )
  {
  //CFish* pFish = dynamic_cast <CFish*> (pOther); 
  auto pFish = dynamic_cast <CFish*> (pOther); 
  if( pFish ) r += 1;                  
  }  

void COcean::addObject( objectType type, 
                 int x0, int y0, int r0, 
                 int v0, double course0 )        
  {
  COceanObject* pNewObj = nullptr;        
  if( type == STONE )                  
    pNewObj = new CStone( x0, y0, r0 );
  else if( type == GRASS )             
    pNewObj = new CGrass( x0, y0, r0 );
  else if( type == FISH )
    pNewObj = new CFish( x0, y0, r0, v0, 
                         course0 );
  else /* if( type == HUNTER ) */
    pNewObj = new CHunter( x0, y0, r0, v0 );       
  if( pNewObj )                        
    pObjects.push_back( pNewObj );     
  }
  
void COcean::update()  
  {
  for( auto pObj: pObjects ) 
    pObj->update();
  checkCollisions();
  removeDead();  
  }

COcean::~COcean() 
  {
  for( auto pObj: pObjects ) 
    delete pObj;
  }    

void COcean::checkCollisions() const
  {
  for( int i = 0; i < pObjects.size(); i++ ) 
    for( int j = i+1; j < pObjects.size(); j++ )  
      if( pObjects[i]->hasCollisionWith
                      (pObjects[j]) ) {      
        pObjects[i]->collideWith( pObjects[j] );
        pObjects[j]->collideWith( pObjects[i] );
        }
  }     
  
void COcean::removeDead()
  {
  for( int i = pObjects.size()-1; i >= 0; i-- ) 
    if( pObjects[i]->isDead() ) {
      delete pObjects[i];                   
      pObjects.erase( pObjects.begin()+i ); 
      }
  }                  


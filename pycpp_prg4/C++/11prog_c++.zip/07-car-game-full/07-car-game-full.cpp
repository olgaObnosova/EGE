//
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 4 (11 �����)
// ��������� � 7. ������ ���� "������ �� ������" � �������
//

#include "TXLib.h"
#include <iostream>
#include <random>
#include <cmath>
#include <sstream>
#include "cargame.hpp"

using namespace std;

int randInt( int a, int b ) {
  return a + rand() % (b-a+1);  
  }

const int CELL_SIZE = 20;   

COLORREF cellColor( cellType type )
  {
  COLORREF color;
  if( type == EMPTY )  
    color = RGB(50, 255, 50);
  else if( type == SIDE )
    color = RGB(80, 0, 0); 
  else if( type == WALL )
    color = RGB(0, 80, 0); 
  else /* if( type == CAR ) */
    color = RGB(0, 0, 255); 
  return color;
  }
   
void drawCell( int x, int y, cellType type )
  {
  COLORREF color = cellColor( type );   
  txSetColor( color );
  txSetFillColor( color );
  int left = x*CELL_SIZE,
      top = y*CELL_SIZE;      
  txRectangle( left, top, 
      left+CELL_SIZE, top+CELL_SIZE );
  }

void drawCar( int x, int y )
  {
  COLORREF color = RGB(0, 0, 255);   
  txSetColor( color );
  txSetFillColor( color );
  int xCenter = x*CELL_SIZE + CELL_SIZE / 2,
      yCenter = y*CELL_SIZE + CELL_SIZE / 2;      
  POINT car[] = { {xCenter-5,yCenter}, {xCenter,yCenter-10}, 
                  {xCenter+5,yCenter}, {xCenter,yCenter+10}};    
  txPolygon( car, 4 );
  }

string intToString( int n )
{
  ostringstream temp;
  temp << n;
  string s = temp.str();
  return s;
}

int main()
  {
  const int W = 15, H = 20;     
  CMap map( W, H );           
  
  CCar car( map, 10, 17 );
  
  int score = 0;  
  
  txCreateWindow(W*CELL_SIZE, (H+1)*CELL_SIZE); 
  txBegin();
  
  int betweenObstacles = 10; 
  int toNextObstacle = betweenObstacles;
  const int changeDensityInterval = 200;
  
  int timeInterval = 100;
  
  while( not GetAsyncKeyState(VK_ESCAPE) ) { 
  
    txSetFillColor( TX_WHITE );
    txClear();                          
  
    if( GetAsyncKeyState(VK_LEFT) )     
      car.moveBy( -1 );         
    if( GetAsyncKeyState(VK_RIGHT) )    
      car.moveBy( 1 );
  
    map.show();                        
    car.show();   
	
	string scoreText = "Score: " + intToString(score);                      
    txTextOut(20, H*CELL_SIZE, scoreText.c_str() );
    txSleep( timeInterval );                        
    
    toNextObstacle--;
    if( not toNextObstacle )  {
      map.scroll( 1 );
      toNextObstacle = betweenObstacles;    
    }  
    else map.scroll( 0 ); 
    
    if( not map.isFree(car.x, car.y) ) {
      txSelectFont ("Arial", 40);  	
      txTextOut( 50, (8)*CELL_SIZE, "Game over..." );
      break;   
      }       
    score++;
    
    if( score % changeDensityInterval == 0  
	    and betweenObstacles > 3 ) 
    	betweenObstacles--;

    timeInterval = round(100*exp(-6.7e-004*score));
    
    }
  txEnd();  
  
  }    



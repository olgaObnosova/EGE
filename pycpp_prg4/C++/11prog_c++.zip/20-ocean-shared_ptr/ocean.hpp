// ������������ ����
//
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 4 (11 �����)
// ��������� � 20. ������ �����. ������������� "�����" ����������
//

#include <cmath>
#include <vector>
#include <windows.h>
#include <memory>

enum objectType { STONE, GRASS, FISH, HUNTER };          

const int SCREEN_WIDTH = 600,
          SCREEN_HEIGHT = 400;

void drawObject( int x, int y, int r, objectType type );

class COceanObject 
  {
  protected:
    int x, y, r;
    COceanObject( int x0, int y0, int r0 ):
      x(x0), y(y0), r(r0) {}
  public:  	
    void update() { change();  show(); }       
    virtual void change() = 0;    
    virtual void show() const = 0;    
    virtual ~COceanObject() = default;
	virtual bool isDead() const { return (r == 0); }  
    bool hasCollisionWith( std::shared_ptr<COceanObject> pOther ) const;  
    virtual void collideWith( std::shared_ptr<COceanObject> pOther ) {}  
  };
  
class CStone: public COceanObject
  {
  public:    
    CStone( int x0, int y0, int r0 ):
      COceanObject( x0, y0, r0 ) {}
    virtual void change() override 
      { }
    virtual void show() const override 
      { 
      drawObject( x, y, r, STONE );          
      }      
  };
  
class CGrass: public COceanObject
  {
  public:    
    CGrass( int x0, int y0, int r0 ): COceanObject( x0, y0, r0 )                          
      { }
    virtual void change() override 
      { }
    virtual void show() const override 
      { 
      drawObject( x, y, r, GRASS );          
      }      
  };
 
class CMovingObject: public COceanObject
  {
  protected:    
    double v,       // ��������
           course;  // ���� � ��������       

  public:
    CMovingObject( int x0, int y0, int r0, 
               double v0, double course0 = 0 ):
       COceanObject( x0, y0, r0 )                          
       { 
       v = v0; course = course0;
       }

     virtual void move();
  };

class CFish: public CMovingObject
  {
  public:    
    CFish( int x0, int y0, int r0, 
           double v0, double course0 ):
      CMovingObject( x0, y0, r0, v0, course0 )
      {}
    virtual void change() override 
      { move(); }
    virtual void show() const override 
      { drawObject( x, y, r, FISH ); }      
    virtual void collideWith( std::shared_ptr<COceanObject> pOther ) override; 
  };
 
class CHunter: public CMovingObject 
  {
  public:    
    CHunter( int x0, int y0, int r0, int v0 ):
     CMovingObject( x0, y0, r0, v0 )                     
      {}
    virtual void change() override; 
    virtual void show() const override 
      { drawObject( x, y, r, HUNTER ); }              
    virtual void collideWith( std::shared_ptr<COceanObject> pOther ) override; 
  };          
 
class COcean 
  {
  private:
    std::vector<std::shared_ptr<COceanObject>> pObjects;
  public:
	void addObject( objectType type, 
         int x0, int y0, int r0 = 10, 
         int v0 = 0, double course0 = 0 );        
    void update(); 
    void checkCollisions() const; 
    void removeDead(); 
  };
 

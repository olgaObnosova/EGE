//
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 4 (11 �����)
// ��������� � 21. �����. "�����" ���������
//

#include "TXLib.h"
#include <iostream>
#include <random>
#include <memory>

using namespace std;

enum objectType { STONE, GRASS, FISH, HUNTER };          
const int SCREEN_WIDTH = 600,
          SCREEN_HEIGHT = 400;

int randInt( int a, int b ) {
  return a + rand() % (b-a+1);  
  }

void drawCircle( int x, int y, int r, 
                 COLORREF fillColor )
  {
  txSetColor( RGB(0,0,0) );          
  txSetFillColor( fillColor );               
  txCircle( x, y, r );  
  }  

void drawObject( int x, int y, int r, 
                 objectType type )
  {
  if( type == STONE ) 
    drawCircle( x, y, r, RGB(0,0,0) ); 
  else if( type == GRASS ) 
    drawCircle( x, y, r, RGB(0,255,0) ); 
  else if( type == FISH ) 
    drawCircle( x, y, r, RGB(0,0,255) ); 
  else /* if( type == HUNTER ) */
    drawCircle( x, y, r, RGB(255,0,0) ); 
  }      

class COceanObject 
  {
  protected:
    int x, y, r;
    COceanObject( int x0, int y0, int r0 ):
      x(x0), y(y0), r(r0) {}
  public:
    void update() { change();  show(); }       
    virtual ~COceanObject() = default;    
    virtual void change() = 0;    
    virtual void show() const = 0;    
  };
  
class CStone: public COceanObject
  {
  public:    
    CStone( int x0, int y0, int r0 ):
      COceanObject( x0, y0, r0 ) {}
    virtual void change() {}
    virtual ~CStone() { cout << "Deleting CStone" << endl; }
    virtual void show() const 
      { 
      drawObject( x, y, r, STONE );          
      }      
  };
  
class CGrass: public COceanObject
  {
  public:    
    CGrass( int x0, int y0, int r0 ): COceanObject( x0, y0, r0 )  { }
    virtual ~CGrass() { cout << "Deleting CGrass" << endl; }
    virtual void change() { }
    virtual void show() const 
      { 
      drawObject( x, y, r, GRASS );          
      }      
  };

void showCount( shared_ptr<COceanObject> pObj ) 
{
   cout << pObj.use_count() << endl;
}
 
int main()
  {


  {
  shared_ptr<COceanObject> pObj;  
  cout << pObj.use_count() << endl;
  
// ��� ���� �������:
//  CStone stone = CStone( 100, 100, 8 );    
//  pObj = make_shared<CStone>( stone );    
  
  pObj = make_shared<CStone>( 100, 100, 8 );    
  cout << pObj.use_count() << endl;
    {
    auto pObj2 = pObj; 
    cout << pObj.use_count() << endl;
    cout << pObj2.use_count() << endl;
    }  
  cout << pObj.use_count() << endl;
  }
  cin.get();
  
  vector<shared_ptr<COceanObject>> allObjects;

  const int NUMBER_OF_STONES = 10; 
  for( int i = 0; i < NUMBER_OF_STONES; i++ ) 
    allObjects.push_back (
	       make_shared<CStone>(
                   randInt(0, SCREEN_WIDTH), 
                   randInt(0, SCREEN_HEIGHT), 
                   randInt(5, 15) ) );   

  const int NUMBER_OF_GRASS = 10;

  for( int i = 0; i < NUMBER_OF_GRASS; i++ ) 
    allObjects.push_back (
	       make_shared<CGrass> (
                       randInt(0, SCREEN_WIDTH), 
                       randInt(0, SCREEN_HEIGHT), 
                       randInt(5, 15) ) );   
 
  txCreateWindow( SCREEN_WIDTH, SCREEN_HEIGHT );
  
  while( not GetAsyncKeyState(VK_ESCAPE) )  {
    txSetFillColor( TX_WHITE );
    txClear();             
    for( auto obj: allObjects ) 
      obj->update();
	txSleep( 50 );        
    }
    
  }    



//
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 4 (11 �����)
// ��������� � 13. �����. ����������� �������. �����
//

#include "TXLib.h"
#include <iostream>
#include <cstdlib>

using namespace std;

enum objectType { STONE, GRASS, FISH, HUNTER };          
const int SCREEN_WIDTH = 600,
          SCREEN_HEIGHT = 400;

int randInt( int a, int b ) {
  return a + rand() % (b-a+1);  
  }

void drawCircle( int x, int y, int r, 
                 COLORREF fillColor )
  {
  txSetColor( RGB(0,0,0) );          
  txSetFillColor( fillColor );               
  txCircle( x, y, r );  
  }  

void drawObject( int x, int y, int r, 
                 objectType type )
  {
  if( type == STONE ) 
    drawCircle( x, y, r, RGB(0,0,0) ); 
  else if( type == GRASS ) 
    drawCircle( x, y, r, RGB(0,255,0) ); 
  else if( type == FISH ) 
    drawCircle( x, y, r, RGB(0,0,255) ); 
  else /* if( type == HUNTER ) */
    drawCircle( x, y, r, RGB(255,0,0) ); 
  }      

class COceanObject 
  {
  protected:
    int x, y, r;
    COceanObject( int x0, int y0, int r0 ):
      x(x0), y(y0), r(r0) {}
  public:
    void update() { change();  show(); }       
    virtual void change() = 0;    
    virtual void show() const = 0;    
  };
  
class CStone: public COceanObject
  {
  public:    
    CStone( int x0, int y0, int r0 ):
      COceanObject( x0, y0, r0 ) {}
    virtual void change() override 
	  { }
    virtual void show() const override 
      { 
      drawObject( x, y, r, STONE );          
      }      
  };
  
class CGrass: public COceanObject
  {
  public:    
    CGrass( int x0, int y0, int r0 ): COceanObject( x0, y0, r0 )                          
      { }
    virtual void change() override 
      { }
    virtual void show() const override 
      { 
      drawObject( x, y, r, GRASS );          
      }      
  };
 

int main()
  {
  const int NUMBER_OF_STONES = 10;
  vector<COceanObject> allObjects;      
  
  for( int i = 0; i < NUMBER_OF_STONES; i++ ) 
    allObjects.push_back ( CStone(
                   randInt(0, SCREEN_WIDTH), 
                   randInt(0, SCREEN_HEIGHT), 
                   randInt(5, 15) ) );   


  const int NUMBER_OF_GRASS = 10;

  for( int i = 0; i < NUMBER_OF_GRASS; i++ ) 
    allObjects.push_back( CGrass(
                       randInt(0, SCREEN_WIDTH), 
                       randInt(0, SCREEN_HEIGHT), 
                       randInt(5, 15) ) );   

  txCreateWindow( SCREEN_WIDTH, SCREEN_HEIGHT );
  
  while( not GetAsyncKeyState(VK_ESCAPE) )  {
    txSetFillColor( TX_WHITE );
    txClear();             
    for( COceanObject &obj: allObjects ) 
      obj.update();               // (3) 
    txSleep( 50 );        
    }

  }    



//
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 4 (11 �����)
// ��������� � 14. �����. ��������� �������. ����
//

#include "TXLib.h"
#include <iostream>
#include <cstdlib>

using namespace std;

enum objectType { STONE, GRASS, FISH, HUNTER };          
const int SCREEN_WIDTH = 600,
          SCREEN_HEIGHT = 400;

int randInt( int a, int b ) {
  return a + rand() % (b-a+1);  
  }

void drawCircle( int x, int y, int r, 
                 COLORREF fillColor )
  {
  txSetColor( RGB(0,0,0) );          
  txSetFillColor( fillColor );               
  txCircle( x, y, r );  
  }  

void drawObject( int x, int y, int r, 
                 objectType type )
  {
  if( type == STONE ) 
    drawCircle( x, y, r, RGB(0,0,0) ); 
  else if( type == GRASS ) 
    drawCircle( x, y, r, RGB(0,255,0) ); 
  else if( type == FISH ) 
    drawCircle( x, y, r, RGB(0,0,255) ); 
  else /* if( type == HUNTER ) */
    drawCircle( x, y, r, RGB(255,0,0) ); 
  }      

class COceanObject 
  {
  protected:
    int x, y, r;
    COceanObject( int x0, int y0, int r0 ):
      x(x0), y(y0), r(r0) {}
  public:
    void update() { change();  show(); }       
    virtual void change() = 0;    
    virtual void show() const = 0;    
  };
  
class CStone: public COceanObject
  {
  public:    
    CStone( int x0, int y0, int r0 ):
      COceanObject( x0, y0, r0 ) {}
    virtual void change() override 
	  { }
    virtual void show() const override 
      { 
      drawObject( x, y, r, STONE );          
      }      
  };
  
class CGrass: public COceanObject
  {
  public:    
    CGrass( int x0, int y0, int r0 ): COceanObject( x0, y0, r0 )                          
      { }
    virtual void change() override 
      { }
    virtual void show() const override 
      { 
      drawObject( x, y, r, GRASS );          
      }      
  };
 
class CMovingObject: public COceanObject
  {
  protected:    
    double v,       // ��������
           course;  // ���� � ��������       

  public:
    CMovingObject( int x0, int y0, int r0, 
               double v0, double course0 = 0 ):
       COceanObject( x0, y0, r0 ), v(v0), course(course0)   
	   { }
    virtual void move() 
      {
      double courseRadians = course*M_PI/180;
      x += round(v*cos(courseRadians));         
      y -= round(v*sin(courseRadians));
      if( x-r < 0 ) x += SCREEN_WIDTH;        
      if( x+r > SCREEN_WIDTH ) 
        x -= SCREEN_WIDTH;        
      if( y-r < 0 ) y += SCREEN_HEIGHT;        
      if( y+r > SCREEN_HEIGHT ) 
        y -= SCREEN_HEIGHT;        
      } 
  };

class CFish: public CMovingObject
  {
  public:    
    CFish( int x0, int y0, int r0, 
           double v0, double course0 ):
      CMovingObject( x0, y0, r0, v0, course0 )
      {}
    virtual void change() override 
      { move(); }
    virtual void show() const override 
      { drawObject( x, y, r, FISH ); }      
  };
 

int main()
  {
  const int NUMBER_OF_STONES = 10;
  
  CStone* pStones[NUMBER_OF_STONES];      
  
  for( int i = 0; i < NUMBER_OF_STONES; i++ ) 
  pStones[i] = new CStone(
                   randInt(0, SCREEN_WIDTH), 
                   randInt(0, SCREEN_HEIGHT), 
                   randInt(5, 15) );   

  const int NUMBER_OF_GRASS = 10;
  CGrass* pGrass[NUMBER_OF_GRASS];      

  for( int i = 0; i < NUMBER_OF_GRASS; i++ ) 
    pGrass[i] = new CGrass(
                       randInt(0, SCREEN_WIDTH), 
                       randInt(0, SCREEN_HEIGHT), 
                       randInt(5, 15) );   

  const int NUMBER_OF_FISH = 10;
  CFish* pFish[NUMBER_OF_FISH];      

  for( int i = 0; i < NUMBER_OF_FISH; i++ ) 
    pFish[i] = new CFish(
                       randInt(0, SCREEN_WIDTH), 
                       randInt(0, SCREEN_HEIGHT), 
					   5, 2, 
                       randInt(0, 360) );   

  txCreateWindow( SCREEN_WIDTH, SCREEN_HEIGHT );
  
  while( not GetAsyncKeyState(VK_ESCAPE) )  {
    txSetFillColor( TX_WHITE );
    txClear();             
    for( int i = 0; i < NUMBER_OF_STONES; i++ ) 
      pStones[i]->update();
    for( int i = 0; i < NUMBER_OF_GRASS; i++ ) 
      pGrass[i]->update();
    for( int i = 0; i < NUMBER_OF_FISH; i++ ) 
      pFish[i]->update();
    txSleep( 50 );        
    }

  for( int i = 0; i < NUMBER_OF_STONES; i++ ) 
    delete pStones[i];
  for( int i = 0; i < NUMBER_OF_GRASS; i++ ) 
    delete pGrass[i];
  for( int i = 0; i < NUMBER_OF_FISH; i++ ) 
    delete pFish[i];

  }    



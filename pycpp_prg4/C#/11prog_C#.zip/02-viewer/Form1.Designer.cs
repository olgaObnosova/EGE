﻿namespace Components
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.sizeCb = new System.Windows.Forms.CheckBox();
            this.openBtn = new System.Windows.Forms.Button();
            this.img = new System.Windows.Forms.PictureBox();
            this.openDlg = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.img)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.sizeCb);
            this.panel1.Controls.Add(this.openBtn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(410, 66);
            this.panel1.TabIndex = 0;
            // 
            // sizeCb
            // 
            this.sizeCb.AutoSize = true;
            this.sizeCb.Location = new System.Drawing.Point(204, 20);
            this.sizeCb.Name = "sizeCb";
            this.sizeCb.Size = new System.Drawing.Size(167, 24);
            this.sizeCb.TabIndex = 1;
            this.sizeCb.Text = "По размерам окна";
            this.sizeCb.UseVisualStyleBackColor = true;
            this.sizeCb.CheckedChanged += new System.EventHandler(this.SizeCb_CheckedChanged);
            // 
            // openBtn
            // 
            this.openBtn.Location = new System.Drawing.Point(13, 14);
            this.openBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.openBtn.Name = "openBtn";
            this.openBtn.Size = new System.Drawing.Size(171, 35);
            this.openBtn.TabIndex = 0;
            this.openBtn.Text = "Открыть файл";
            this.openBtn.UseVisualStyleBackColor = true;
            this.openBtn.Click += new System.EventHandler(this.OpenBtn_Click);
            // 
            // img
            // 
            this.img.BackColor = System.Drawing.SystemColors.Window;
            this.img.Dock = System.Windows.Forms.DockStyle.Fill;
            this.img.Location = new System.Drawing.Point(0, 66);
            this.img.Name = "img";
            this.img.Size = new System.Drawing.Size(410, 192);
            this.img.TabIndex = 1;
            this.img.TabStop = false;
            // 
            // openDlg
            // 
            this.openDlg.Filter = "\"Файлы с рисунками|*.jpg;*.jpeg;*.gif;*.png;*.bmp\"";
            this.openDlg.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenDlg_FileOk);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 258);
            this.Controls.Add(this.img);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MainForm";
            this.Text = "Просмотр рисунков";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.img)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox sizeCb;
        private System.Windows.Forms.Button openBtn;
        private System.Windows.Forms.PictureBox img;
        private System.Windows.Forms.OpenFileDialog openDlg;
    }
}


﻿/*
  Программы к учебному пособию "Программирование на языках Python и C++".
  Автор: К.Ю. Поляков
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  11 класс. Визуальное программирование на C#.
  Проект. Использование компонентов
  
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Components
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void OpenBtn_Click(object sender, EventArgs e)
        {
            if (openDlg.ShowDialog() == DialogResult.OK)
            {
                img.Image = new Bitmap(openDlg.FileName);
            }
        }

        private void SizeCb_CheckedChanged(object sender, EventArgs e)
        {
            if (sizeCb.Checked)
                img.SizeMode = PictureBoxSizeMode.Zoom;
            else img.SizeMode = PictureBoxSizeMode.Normal;
        }

        private void OpenDlg_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
}

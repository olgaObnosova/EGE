﻿/*
  Программы к учебнику информатики для 11 класса углублённого уровня.
  Визуальное программирование на C#.
  Авторы: К.Ю. Поляков, Е.А. Еремин
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  Глава 7. Объектно-ориентированное программирование
  Проект № 6. Усовершенствование компонента TextBox
  
*/
namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.decEdit = new WindowsFormsApplication1.IntTextBox();
            this.hexLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // decEdit
            // 
            this.decEdit.Font = new System.Drawing.Font("Courier New", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.decEdit.Location = new System.Drawing.Point(4, 6);
            this.decEdit.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.decEdit.Name = "decEdit";
            this.decEdit.Size = new System.Drawing.Size(140, 29);
            this.decEdit.TabIndex = 0;
            this.decEdit.Text = "0";
            this.decEdit.Value = 0;
            this.decEdit.TextChanged += new System.EventHandler(this.decEdit_TextChanged);
            // 
            // hexLabel
            // 
            this.hexLabel.AutoSize = true;
            this.hexLabel.Font = new System.Drawing.Font("Courier New", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.hexLabel.ForeColor = System.Drawing.Color.Navy;
            this.hexLabel.Location = new System.Drawing.Point(152, 9);
            this.hexLabel.Name = "hexLabel";
            this.hexLabel.Size = new System.Drawing.Size(76, 22);
            this.hexLabel.TabIndex = 1;
            this.hexLabel.Text = "123234";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(257, 41);
            this.Controls.Add(this.hexLabel);
            this.Controls.Add(this.decEdit);
            this.Font = new System.Drawing.Font("Courier New", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form1";
            this.Text = "Шестнадцатеричная система";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private IntTextBox decEdit;
        private System.Windows.Forms.Label hexLabel;
    }
}


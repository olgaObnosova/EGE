﻿/*
  Программы к учебному пособию "Программирование на языках Python и C++".
  Автор: К.Ю. Поляков
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  11 класс. Визуальное программирование на C#.
  Проект. Усовершенствование компонента TextBox
  
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class IntTextBox : TextBox
    {
        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || e.KeyChar == (char)8))
                e.KeyChar = (char)0;
            base.OnKeyPress(e);
        }
        public int Value
        {
            set { Text = value.ToString(); }
            get
            {
                try { return int.Parse(Text); }
                catch { return 0; }
            }
        }
    }

}

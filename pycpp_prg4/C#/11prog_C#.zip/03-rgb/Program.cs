﻿/*
  Программы к учебному пособию "Программирование на языках Python и C++".
  Автор: К.Ю. Поляков
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  11 класс. Визуальное программирование на C#.
  Проект. Использование компонентов
  
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace InputComponents
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}

﻿/*
  Программы к учебному пособию "Программирование на языках Python и C++".
  Автор: К.Ю. Поляков
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  11 класс. Визуальное программирование на C#.
  Проект. Использование компонентов
  
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace InputComponents
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // rEdit_TextChanged(rEdit, e);
            rEdit_TextChanged(null, null);
        }

        private void rEdit_TextChanged(object sender, EventArgs e)
        {
            int r, g, b;
            try
            {
                r = int.Parse(rEdit.Text);
                g = int.Parse(gEdit.Text);
                b = int.Parse(bEdit.Text);
                rgbLabel.Text = "#" + r.ToString("X2") + g.ToString("X2") + b.ToString("X2");
                rgbPanel.BackColor = Color.FromArgb(r, g, b);
            }
            catch
            {
                rgbLabel.Text = "?";
            }
        }

        private void rEdit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ( ! ( Char.IsDigit(e.KeyChar) || e.KeyChar == (char) 8) )
                e.Handled = true;
        }
    }
}

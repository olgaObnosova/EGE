﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace StringCalculator
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void input_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                int x = Calculator.calc(input.Text);
                answers.Text += input.Text + "=" + x.ToString() + "\r\n";
                int i = input.FindString(input.Text);
                if (i < 0)
                    input.Items.Insert(0, input.Text);
            }
        }
    }
}

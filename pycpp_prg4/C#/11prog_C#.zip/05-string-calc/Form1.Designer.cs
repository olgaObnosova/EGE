﻿namespace StringCalculator
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.input = new System.Windows.Forms.ComboBox();
            this.answers = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // input
            // 
            this.input.Dock = System.Windows.Forms.DockStyle.Top;
            this.input.FormattingEnabled = true;
            this.input.Location = new System.Drawing.Point(0, 0);
            this.input.Name = "input";
            this.input.Size = new System.Drawing.Size(350, 21);
            this.input.TabIndex = 0;
            this.input.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.input_KeyPress);
            // 
            // answers
            // 
            this.answers.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.answers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.answers.Location = new System.Drawing.Point(0, 21);
            this.answers.Multiline = true;
            this.answers.Name = "answers";
            this.answers.ReadOnly = true;
            this.answers.Size = new System.Drawing.Size(350, 205);
            this.answers.TabIndex = 1;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 226);
            this.Controls.Add(this.answers);
            this.Controls.Add(this.input);
            this.Name = "MainForm";
            this.Text = "Калькулятор";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox input;
        private System.Windows.Forms.TextBox answers;
    }
}


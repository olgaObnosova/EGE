﻿/*
  Программы к учебному пособию "Программирование на языках Python и C++".
  Автор: К.Ю. Поляков
  E-mail: kpolyakov@mail.ru
  Сайт поддержки: http://kpolyakov.spb.ru

  11 класс. Визуальное программирование на C#.
  Проект. Строчный калькулятор
  
*/
using System;
using System.Collections.Generic;
using System.Text;

namespace StringCalculator
{
    class Calculator
    {
        public static int calc(string expr)
        {
            int pos = lastOp(expr);
            if (pos < 0) return int.Parse(expr);
            int n1 = calc(expr.Substring(0, pos)); // левая часть
            int n2 = calc(expr.Substring(pos + 1));  // правая часть 
            return doOperation(expr[pos], n1, n2);
        }
        static int lastOp(string expr)
        {
            int minPrt = 50, posLastOp = -1;
            for (int i = 0; i < expr.Length; i++)
              if (priority(expr[i]) <= minPrt) { 
                minPrt = priority(expr[i]);
                posLastOp = i;
                }
            return posLastOp;
        }
        static int priority(char op)
        {
            if( op == '+' || op == '-') return 1;
            if( op == '*' || op == '/') return 2;
            return 100;
        }
        static int doOperation(char op, int n1, int n2)
        {
            if (op == '+') return n1 + n2;
            else if (op == '-') return n1 - n2;
            else if (op == '*') return n1 * n2;
            else return n1 / n2;
        }


    }
}

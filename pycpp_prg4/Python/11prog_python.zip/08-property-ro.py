# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 8. Свойство только для чтения
#

class TCar:
  def __init__( self, _v ):
    self.__velocity = _v
  @property
  def velocity(self):
    return self.__velocity
  # velocity = property ( lambda x: x.__velocity )

car = TCar( 25 )
print( "v =", car.velocity )

class TRect():
  def __init__( self, a, b ):
    self.__a = a
    self.__b = b
  area = property( lambda x: x.__a*x.__b )

rct = TRect( 2, 3 )
print( "Площадь:", rct.area )



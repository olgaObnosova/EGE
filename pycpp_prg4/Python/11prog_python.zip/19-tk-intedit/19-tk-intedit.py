# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 19. Создание нового компонента TIntEdit
#

from simpletk import *
from int_edit import TIntEdit

f = ("Courier New", 14, "bold")

app = TApplication("Шестнадцатеричная система")
app.size = (250, 36)
app.position = (200, 200)

hexLabel = TLabel(app, text="?", font=f, fg="navy" )
hexLabel.position = (155, 5)

def onNumChange(sender):
  hexLabel.text = "{:X}".format(sender.value)

decEdit = TIntEdit(app, width=12, font = f)
decEdit.position = (5, 5)
decEdit.text = "1001"
decEdit.onChange = onNumChange

app.run()

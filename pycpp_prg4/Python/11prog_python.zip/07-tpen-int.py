# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 7. Объект Перо - свойство с преобразованием
#

class TPen:
  def __init__( self ):
    self.__color = 0
  def __getColor( self ):
    return "{:06X}".format( self.__color )
  def __setColor( self, newColor ):
    if len(newColor) == 6:
          self.__color = int( newColor, 16 )
    else: self.__color = 0
  color = property ( __getColor, __setColor )

pen = TPen()
pen.color = "FFFF00"
print( "Цвет пера:", pen.color )

# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 22. Калькулятор (модель - представление)
#

from model import calc
from simpletk import *

app = TApplication("Калькулятор")
app.size = (200, 150)

inp = TComboBox(app, values=[], height=1)
inp.align = "top"
inp.text = "2+2"

answers = TListBox(app)
answers.align = "client"

def doCalc(event):
  expr = inp.text
  x = calc(expr)
  answers.insert(0, expr+"="+str(x))
  if not inp.findItem(expr):
    inp.addItem(expr)

inp.bind('<Key-Return>', doCalc)

app.run()

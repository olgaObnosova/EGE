# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 4. Игра "Морской бой"
#

from graph import *
from math import hypot

SCREEN_WIDTH = 740
SCREEN_HEIGHT = 438
HORIZONT_Y = 225
fps = 20
updatePeriod = round(1000 / fps)

windowSize(SCREEN_WIDTH, SCREEN_HEIGHT)
canvasSize(SCREEN_WIDTH, SCREEN_HEIGHT)
image(0, 0, "back.gif")

class TShip:
  SHIP_Y = 202
  EXPLODE_TIME = 2
  def __init__(self, velocity):
    self.velocity = velocity
    self.pos = SCREEN_WIDTH - 100
    self.image = image(self.pos, TShip.SHIP_Y, "ship.gif")
    self.explodeImage = None
    self.explodeTime = 0
  def move(self):
    moveObjectBy(self.image, -self.velocity, 0)
    x1, y1, x2, y2 = coords(self.image)
    if x2 < 0:
       moveObjectBy(self.image, SCREEN_WIDTH+x2-x1, 0)
  def update(self):
    if self.explodeTime:
      self.explodeTime -= 1
      if not self.explodeTime:
        deleteObject(self.explodeImage)
        self.explodeImage = None
        x1, y1, x2, y2 = coords(self.image)
        moveObjectBy(self.image, SCREEN_WIDTH-x1, 0)
    else:
      self.move()
  def explode(self, xPos):
    self.explodeImage = image(xPos, HORIZONT_Y, "explosion.gif", anchor = CENTER)
    self.explodeTime = round(TShip.EXPLODE_TIME*1000/ updatePeriod)

class TTube:
  PREPARE_TIME = 5
  X_TUBE = SCREEN_WIDTH // 2
  Y_TUBE = SCREEN_HEIGHT - 10
  def __init__(self, xPos):
    self.image = image(xPos, 0, "aim.gif")
    self.torpedoes = []
    self.torpFinished = []
    self.timeToShot = 0
  def keyPressed(self, event):
    if event.keycode == VK_LEFT:
      moveObjectBy(self.image, -2, 0)
    if event.keycode == VK_RIGHT:
      moveObjectBy(self.image, 2, 0)
    if event.keycode == VK_SPACE:
      self.shoot()
  def shoot(self):
    if self.timeToShot > 0: return
    x1, y1, x2, y2 = coords(self.image)
    xAim = (x1 + x2) // 2
    self.torpedoes.append( TTorpedo(xAim, TTube.X_TUBE, TTube.Y_TUBE) )
    self.timeToShot = round(TTube.PREPARE_TIME*1000 / updatePeriod)
  def update(self):
    self.moveTorpedoes()
    if self.timeToShot:
      self.timeToShot -= 1
  def moveTorpedoes(self):
    for torp in self.torpedoes:
      if not torp.move():
         self.torpFinished.append(center(torp.image))
         deleteObject(torp.image)
         self.torpedoes.remove(torp)


class TTorpedo:
  TORPEDO_VELOCITY = 10
  def __init__(self, aimX, xStart, yStart):
    self.aimX = aimX
    self.velocity = TTorpedo.TORPEDO_VELOCITY
    penColor("black")
    brushColor("white")
    self.image = circle(xStart, yStart, 5)
  def move(self):
    xCenter, yCenter = center(self.image)
    if yCenter <= HORIZONT_Y: return False
    dist = hypot(self.aimX-xCenter, yCenter-HORIZONT_Y)
    part = self.velocity / dist
    self.velocity *= 0.97
    newX = xCenter + part*(self.aimX - xCenter)
    newY = yCenter + part*(HORIZONT_Y - yCenter)
    moveObjectBy(self.image, newX - xCenter, newY - yCenter)
    return True

def checkCollision(ship, tube):
  x1, y1, x2, y2 = coords(ship.image)
  for pos in tube.torpFinished:
    if x1 <= pos[0] <= x2:
      ship.explode(pos[0])
    tube.torpFinished.remove(pos)

def update():
  ship.update()
  tube.update()
  checkCollision(ship, tube)

def keyPressed(event):
  tube.keyPressed(event)

ship = TShip(2)
tube = TTube(SCREEN_WIDTH // 2)

onTimer(update, updatePeriod)
onKey(keyPressed)

run()
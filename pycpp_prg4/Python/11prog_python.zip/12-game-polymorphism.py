# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 12. Игра. Полиморфизм
#

from random import randint
from graph import *

SCREEN_WIDTH = 600   # ширина окна
SCREEN_HEIGHT = 400  # высота окна
fps = 20             # частота кадров
updatePeriod = round(1000 / fps)

class TGameObject:
  def __init__( self, x, y, width, height ):
    self._x = x
    self._y = y
    self._width = width
    self._height = height
    if not hasattr( self, "update" ):
      raise NotImplementedError(
            "Нельзя создать такой объект!")
  @property
  def x( self ): return self._x
  @property
  def y( self ): return self._y
  @property
  def width( self ): return self._width
  @property
  def height( self ): return self._height

class TBlackHole( TGameObject ):
  def __init__(self, xCenter, yCenter, radius):
    TGameObject.__init__( self, xCenter, yCenter,
                          2*radius, 2*radius )
    brushColor("black")
    self._image = circle( xCenter, yCenter,radius )
  def update( self ):
    pass

class TPulsar( TBlackHole ):
  def __init__( self, xCenter, yCenter, radius ):
    TBlackHole.__init__( self, xCenter, yCenter,
                         radius )
    changeFillColor( self._image, "brown" )
  def update( self ):
    self.__changeRadius( randint(5, 20) )
  def __changeRadius(self, newRadius ):
    self._width = 2*newRadius
    self._height = 2*newRadius
    changeCoords( self._image,
      [(self._x-newRadius, self._y-newRadius),
       (self._x+newRadius, self._y+newRadius)] )

def update():
  for obj in allObjects:
    obj.update();

windowSize(SCREEN_WIDTH, SCREEN_HEIGHT)
canvasSize(SCREEN_WIDTH, SCREEN_HEIGHT)

NUMBER_OF_BLACKHOLES = 10
allObjects = []
for i in range(NUMBER_OF_BLACKHOLES):
  allObjects.append( TBlackHole(
          randint(20, SCREEN_WIDTH-50),
          randint(20, SCREEN_HEIGHT-50),
          randint(10, 20) ) )
NUMBER_OF_PULSARS = 15
for i in range(NUMBER_OF_PULSARS):
  allObjects.append( TPulsar(
          randint(20, SCREEN_WIDTH-50),
          randint(20, SCREEN_HEIGHT-50),
          randint(10, 20) ) )

onTimer( update, updatePeriod )

for obj in allObjects:
  print( type(obj) )

run()

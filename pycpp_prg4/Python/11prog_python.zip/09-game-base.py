# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 9. Игра. Базовый класс
#

class TGameObject:
  def __init__( self, x, y, width, height ):
    self._x = x
    self._y = y
    self._width = width
    self._height = height
    if not hasattr( self, "update" ):
      raise NotImplementedError(
            "Нельзя создать такой объект!")
  @property
  def x( self ): return self._x
  @property
  def y( self ): return self._y
  @property
  def width( self ): return self._width
  @property
  def height( self ): return self._height

# Ошибка! Нельзя создать экземпляр абстрактного класса!
obj = TGameObject(100, 50, 10, 10)
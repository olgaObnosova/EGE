# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 16. Программа для посмотра изображений
#

from simpletk import *
from tkinter import filedialog

app = TApplication("Просмотр рисунков")
app.position = (200, 200)
app.size = (300, 300)

panel = TPanel(app, relief="raised", height=35, bd=1)
panel.align = "top"

image = TImage(app, bg="white")
image.align = "client"
image.picture = "flower.gif"
# image.picture = "lamplogo.jpg" # только если есть PIL

def selectFile(sender):
  fname = filedialog.askopenfilename(
     filetypes=[("Файлы GIF", "*.gif"),
                ("Все файлы", "*.*")] )
     #filetypes=[("Файлы GIF", "*.gif"),  # если есть PIL
     #           ("Файлы JPEG", "*.jpg"),
     #           ("Файлы PNG", "*.png"),
     #           ("Все файлы", "*.*")] )
  if fname:
    image.picture = fname

openBtn = TButton(panel, width=15, text="Открыть файл")
openBtn.position = (5, 5)
openBtn.onClick = selectFile

def cbChanged(sender):
  image.center = sender.checked
  image.redrawImage()

centerCb = TCheckBox(panel,text="В центре")
centerCb.position = (115, 5)
centerCb.onChange = cbChanged

app.run()
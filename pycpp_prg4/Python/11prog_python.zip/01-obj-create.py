# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 1. Создание объектов
#

from graph import *

class TShip:
  SHIP_Y = 150
  def __init__( self, x0, v0, fileName ):
    self.x = x0 if x0 >= 0 else 0;
    self.v = v0;
    self.image = image( self.x, TShip.SHIP_Y, fileName )

ship = TShip( 30, 3, "ship.gif" )

run()
# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 10. Игра. Чёрные дыры
#

from random import randint
from graph import *

SCREEN_WIDTH = 600   # ширина окна
SCREEN_HEIGHT = 400  # высота окна
fps = 20             # частота кадров
updatePeriod = round(1000 / fps)

class TGameObject:
  def __init__( self, x, y, width, height ):
    self._x = x
    self._y = y
    self._width = width
    self._height = height
    if not hasattr( self, "update" ):
      raise NotImplementedError(
            "Нельзя создать такой объект!")
  @property
  def x( self ): return self._x
  @property
  def y( self ): return self._y
  @property
  def width( self ): return self._width
  @property
  def height( self ): return self._height

class TBlackHole( TGameObject ):
  def __init__(self, xCenter, yCenter, radius):
    TGameObject.__init__( self, xCenter, yCenter,
                          2*radius, 2*radius )
    brushColor("black")
    self._image = circle( xCenter, yCenter,radius )
  def update( self ):
    pass

windowSize(SCREEN_WIDTH, SCREEN_HEIGHT)
canvasSize(SCREEN_WIDTH, SCREEN_HEIGHT)

NUMBER_OF_BLACKHOLES = 10
blackHoles = []
for i in range(NUMBER_OF_BLACKHOLES):
  blackHoles.append( TBlackHole(
          randint(0, SCREEN_WIDTH),
          randint(0, SCREEN_HEIGHT),
          randint(10, 20) ) )

def update():
  for bh in blackHoles:
    bh.update();

onTimer( update, updatePeriod )

run()

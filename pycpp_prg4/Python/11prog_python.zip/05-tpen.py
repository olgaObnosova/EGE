# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 5. Объект Перо - скрытие данных
#

class TPen:
  def __init__( self ):
    self.__color = "000000"
  def getColor( self ):
    return self.__color
  def setColor( self, newColor ):
    if len(newColor) == 6:
          self.__color = newColor
    else: self.__color = "000000"

pen = TPen()
pen.setColor( "FFFF00" )
print( "Цвет пера:", pen.getColor() )

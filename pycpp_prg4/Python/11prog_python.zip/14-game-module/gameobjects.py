# -*- coding: utf-8
# Модуль с игровыми объектами
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 13. Игра. Использование модуля
#

from graph import *
import math

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
def gameScreenSize( width, height ):
  global SCREEN_WIDTH, SCREEN_HEIGHT
  SCREEN_WIDTH = width
  SCREEN_HEIGHT = height

class TGameObject:
  def __init__( self, x, y, width, height ):
    self._x = x
    self._y = y
    self._width = width
    self._height = height
    if not hasattr( self, "update" ):
      raise NotImplementedError(
            "Нельзя создать такой объект!")
  @property
  def x( self ): return self._x
  @property
  def y( self ): return self._y
  @property
  def width( self ): return self._width
  @property
  def height( self ): return self._height

class TBlackHole( TGameObject ):
  def __init__(self, xCenter, yCenter, radius):
    TGameObject.__init__( self, xCenter, yCenter,
                          2*radius, 2*radius )
    brushColor("black")
    self._image = circle( xCenter, yCenter,radius )
  def update( self ):
    pass

class TPulsar( TBlackHole ):
  def __init__( self, xCenter, yCenter, radius ):
    TBlackHole.__init__( self, xCenter, yCenter,
                         radius )
    changeFillColor( self._image, "brown" )
  def update( self ):
    self.__changeRadius( randint(5, 20) )
  def __changeRadius(self, newRadius ):
    self._width = 2*newRadius
    self._height = 2*newRadius
    changeCoords( self._image,
      [(self._x-newRadius, self._y-newRadius),
       (self._x+newRadius, self._y+newRadius)] )

class TMovingObject(TGameObject):
  def __init__( self, x, y, width, height,
                v, course ):
    TGameObject.__init__( self, x, y, width,
                          height )
    self._v = v
    self._course = course
  def move( self ):
    dx = self._v*math.cos( self._course )
    dy = -self._v*math.sin( self._course )
    self._x += dx
    self._y += dy
    moveObjectBy( self._image, dx, dy )

class TSpaceship( TMovingObject ):
  def __init__( self, xCenter, yCenter,
                radius, v, course ):
    TMovingObject.__init__( self,
        xCenter, yCenter, 2*radius, 2*radius,
        v, course )
    brushColor("blue")
    self._image = circle(
                      xCenter, yCenter, radius )
  def update( self ):
    self.move()    # движение
    self.bounce()  # отскок
  def bounce( self ):
    x1, y1, x2, y2 = coords( self._image )
    if x1 <= 0  or x2 >= SCREEN_WIDTH:
       self._course = math.pi - self._course
    if y1 <= 0  or y2 >= SCREEN_HEIGHT:
       self._course = - self._course

class TRanger( TSpaceship ):
  def __init__( self, xCenter, yCenter,
               radius, v, course ):
    TSpaceship.__init__( self, xCenter, yCenter,
                         radius, v, course )
    changeFillColor( self._image, "yellow" )
  def update( self ):
    if randint(1, 20) == 1:
       self._course = randint(0,359)*math.pi/180
    super().update()

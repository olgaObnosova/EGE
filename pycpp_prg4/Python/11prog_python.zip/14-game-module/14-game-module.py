# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 4 (11 класс)
# Программа № 14. Игра. Использование модуля
#

from random import randint
from graph import *
import math

from gameobjects import *

SCREEN_WIDTH = 600   # ширина окна
SCREEN_HEIGHT = 400  # высота окна
fps = 20             # частота кадров
updatePeriod = round(1000 / fps)

windowSize(SCREEN_WIDTH, SCREEN_HEIGHT)
canvasSize(SCREEN_WIDTH, SCREEN_HEIGHT)

gameScreenSize( SCREEN_WIDTH, SCREEN_HEIGHT )

def update():
  for obj in allObjects:
    obj.update();

NUMBER_OF_BLACKHOLES = 10
allObjects = []
for i in range(NUMBER_OF_BLACKHOLES):
  allObjects.append( TBlackHole(
          randint(20, SCREEN_WIDTH-50),
          randint(20, SCREEN_HEIGHT-50),
          randint(10, 20) ) )

NUMBER_OF_PULSARS = 15
for i in range(NUMBER_OF_PULSARS):
  allObjects.append( TPulsar(
          randint(20, SCREEN_WIDTH-50),
          randint(20, SCREEN_HEIGHT-50),
          randint(10, 20) ) )

NUMBER_OF_SPACESHIPS = 10
SIZE_OF_SPACESHIP = 5
for i in range(NUMBER_OF_SPACESHIPS):
  allObjects.append( TSpaceship(
     randint(0, SCREEN_WIDTH),
     randint(0, SCREEN_HEIGHT),
     SIZE_OF_SPACESHIP,
     randint(1, 5),
     randint(0,359)*math.pi/180 )
     )

NUMBER_OF_RANGERS = 10
SIZE_OF_RANGER = 5
for i in range(NUMBER_OF_RANGERS):
  allObjects.append( TRanger(
     randint(0, SCREEN_WIDTH),
     randint(0, SCREEN_HEIGHT),
     SIZE_OF_RANGER,
     randint(1, 5),
     randint(0,359)*math.pi/180 )
     )

onTimer( update, updatePeriod )

run()

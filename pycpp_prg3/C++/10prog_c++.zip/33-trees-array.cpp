//
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 3 (10 �����)
// ��������� � 33. �������: �������� � �������
//

#include <iostream>
#include <cstdlib>

using namespace std;

struct TTree {    
  int size;
  string *data;
  };

void initTree ( TTree& Tree, int size )
{
   Tree.size = size;
   Tree.data = new string[size];
   for( int i = 0; i < size; i++ )
     Tree.data[i] = "";  
}

void showTree ( TTree& Tree )
{
  for( int i = 0; i < Tree.size; i++ )
    cout << i+1 << ": " << Tree.data[i] << endl;
}

void addToTree ( string s, TTree& Tree, int k )
{
  if ( k >= Tree.size ) {
    string *temp = Tree.data;
    Tree.data = new string[Tree.size+10];  
    for( int i = 0; i < Tree.size; i++ )
      Tree.data[i] = temp[i];
    delete temp;
    Tree.size += 10;   
    for( int i = Tree.size; i < Tree.size; i++ )
      Tree.data[i] = "";  
    }
  Tree.data[k] = s;
}

int priority( char op )
{
  if( op == '+' || op == '-') return 1;
  if( op == '*' || op == '/') return 2;
  return 100;  
} 

int lastOp ( string expr )
  {
  int minPrt = 50, pos = -1;
  for(int i = 0; i < expr.size(); i++ ) {
    int prt = priority(expr[i]);  
    if ( prt <= minPrt ) {
      minPrt = prt;
      pos = i;
      }
    }
  return pos;
  }

void makeTree ( string s, TTree& Tree, int iRoot = 0 )
{
  int k = lastOp ( s );
  if ( k == -1 ) addToTree ( s, Tree, iRoot);
  else {
    addToTree ( s.substr(k,1), Tree, iRoot );
    makeTree( s.substr(0,k), Tree, 2*iRoot+1 );
    makeTree( s.substr(k+1), Tree, 2*iRoot+2 );
    }
}

int doOperation( string op, int n1, int n2 )
  {  
  if( op == "+" ) return n1 + n2; 
  if( op == "-" ) return n1 - n2; 
  if( op == "*" ) return n1 * n2; 
  if( op == "/" ) return n1 / n2; 
  return 9999;
  }

int calcTree ( TTree& Tree, int iRoot = 0 )
{
  int n1, n2, res;
  if( 2*iRoot+1 >= Tree.size or 
      Tree.data[2*iRoot+1][0] == '\0' ) 
    return stoi ( Tree.data[iRoot] );
  n1 = calcTree ( Tree, 2*iRoot+1 );
  n2 = calcTree ( Tree, 2*iRoot+2 );
  return doOperation( Tree.data[iRoot], n1, n2 ); 
}

void deleteTree( TTree& Tree )
  {
  if( Tree.data ) return;
  delete Tree.data;
  Tree.size = 0;
  Tree.data = nullptr;
  }   
 
int main( )
  {  	
  TTree Tree;

  //cout << "Enter ariphmetic expression without brackets: \n";
  //string s;   
  //cin >> s;
  string s = "40-2*3-4*5";  

  initTree ( Tree, s.size() );
  
  makeTree ( s, Tree );
  cout << "Binary tree in array:\n";
  showTree ( Tree );
  
  cout << "Result: " << calcTree( Tree );
     
  cin.get(); cin.get(); 
  }



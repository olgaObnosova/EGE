//
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 3 (10 �����)
// ��������� � 26. ������� � �������
//

#include <iostream>
#include <fstream>
#include <queue>

using namespace std;

const int NMAX = 16;
struct TQueue {
  int data[NMAX];
  int head, tail;	
  };
  
void initQueue( TQueue& Q )
  {
  Q.head = 0;
  Q.tail = NMAX - 1;
  }

bool queueEmpty( TQueue Q )
  {
  int posTailEmpty = Q.head - 1;
  if( posTailEmpty < 0 ) 
    posTailEmpty += NMAX; 	
  return (Q.tail == posTailEmpty);
  }

bool queueFull( TQueue Q )
  {
  int posTailFull = Q.head - 2;
  if( posTailFull < 0 )	
    posTailFull += NMAX;
  return (Q.tail == posTailFull);
  }
  
bool pushQueue( TQueue& Q, int x ) 
  {
  if( queueFull(Q) ) {
  	cout << "Queue full!" << endl;
	return false; 
    }	
  Q.tail = (Q.tail + 1) % NMAX;
  Q.data[Q.tail] = x;
  return true;
  } 
  
int popQueue( TQueue& Q ) 
  {
  if( queueEmpty(Q) ) {
  	cout << "Queue empty!" << endl;
	return 0;
    }	
  int top = Q.data[Q.head];
  Q.head = (Q.head + 1) % NMAX;
  return top;
  } 

void showQueue( TQueue Q ) 
  {
  if( queueEmpty(Q) ) {
  	cout << "[]" << endl;
	return; 
    }	
  int i = Q.head;
  while( 1 ) {
  	cout << Q.data[i] << " ";
  	if( i == Q.tail) break;
  	i = (i+1) %  NMAX;
    }
  cout << endl;
  } 
  

int main( )
  {
  TQueue Q;
  initQueue(Q);
  
  showQueue(Q);
  
  for( int i = 1; i <= 16; i++ ) {
  	cout << "+" << i << ": ";
  	pushQueue(Q, i);
  	showQueue(Q);
    }

  for( int i = 1; i <= 5; i++ ) {
  	cout << "x: ";
  	popQueue(Q);
  	showQueue(Q);
    }
  
  for( int i = 16; i <= 21; i++ ) {
  	cout << "+" << i << ": ";
  	pushQueue(Q, i);
  	showQueue(Q);
    }
  
  for( int i = 1; i <= 16; i++ ) {
  	cout << "x: ";
  	popQueue(Q);
  	showQueue(Q);
    }
    	
  cin.get();  
  }



//
// ��������� � �������� �������
// �.�. �������. ���������������� �� ������ Python � C++
// ����� 3 (10 �����)
// ��������� � 19. ���������
//

#include <iostream>
#include <random>
#include <vector>
#include <algorithm>

using namespace std;

int randInt ( int a, int b )
  {
  return a + rand() % (b-a+1);  
  }
  
void printVector ( const vector<int> A )
  {
  vector <int>::const_iterator itConst;
  for( itConst = A.begin(); itConst < A.end(); itConst++ )
    cout << *itConst << " ";
  cout << endl;    	
  }  

int main( )
  {
  int N = 10;
  
  vector <int> A;
  for( int i = 0; i < N; i++ )
    A.push_back( randInt(20, 90) );
  
  vector <int>::iterator it = A.begin();
  *it = 100;
  cout << *it << " " << A[0] << endl;

  for( it = A.begin(); it != A.end(); it++ )
    cout << *it << " ";
  cout << endl;  

  for( it = A.begin(); it != A.end(); it++ )
    *it = 2018;
  printVector( A );  

  for( auto it2 = A.begin(); it2 != A.end(); it2++ )
    *it2 = randInt(100, 200);
  printVector( A );  

  A.insert( A.begin(), 101 );
  printVector( A );  

  A.erase( A.begin()+2 );
  printVector( A );  
  
  A.erase( A.begin()+2, A.begin()+5 );
  printVector( A );  

  sort( A.begin(), A.end() );
  printVector( A );  
  
  std::random_device rd;
  std::mt19937 rndGen(rd());
  shuffle( A.begin(), A.end(), rndGen );
  printVector( A );  

  fill( A.begin(), A.begin()+2, -1 );
  printVector( A );  

  vector <int>:: const_iterator itConst;
  itConst = find( A.begin(), A.end(), 2018 );
  if( itConst == A.end() )
    cout << "2018 not found!" << endl;
  else  
    cout << "Found 2018..." << endl; 

  itConst = find( A.begin(), A.end(), A[3] );
  if( itConst == A.end() )
    cout << A[3] << " not found!" << endl;
  else  
    cout << A[3] << " found!" << endl; 

  cin.get();  
  }



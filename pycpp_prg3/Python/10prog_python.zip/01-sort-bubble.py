# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 3 (10 класс)
# Программа № 1. Сортировка пузырьком
#

from random import randint

N = 10
A =[randint(10,100) for i in range(N)]
print(A)

for i in range(N-1):
  for j in range(N-1-i):
    if A[j]> A[j+1]:
      A[j], A[j+1] = A[j+1], A[j]
print(A)

# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 3 (10 класс)
# Программа № 4. Сортировка Quick sort
#

import random
from random import randint

N = 10
A =[randint(10,100) for i in range(N)]
print(A)

def qSort ( A ):
  if len(A) <= 1: return A		# (1)
  X = random.choice(A)  			# (2)
  BL = [b for b in A if b < X]	# (3)
  BX = [b for b in A if b == X]	# (4)
  BR = [b for b in A if b > X]	# (5)
  return qSort(BL)+BX+qSort(BR)	# (6)

A = qSort(A)
print(A)

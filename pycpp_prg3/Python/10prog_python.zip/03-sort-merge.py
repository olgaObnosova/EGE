# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 3 (10 класс)
# Программа № 3. Сортировка слиянием
#

from random import randint

N = 10
A =[randint(10,100) for i in range(N)]
print(A)

def mergeSort ( A ):
  if len(A) <= 1: return A
  mid = len(A) // 2
  L = mergeSort( A[:mid] )
  R = mergeSort( A[mid:] )
  return merge(L, R)

def merge(A, B):
  C = []
  while A and B:
    if A[0] <= B[0]:
      C.append(A.pop(0))
    else:
      C.append(B.pop(0))
  return C + A + B

A = mergeSort(A)
print(A)

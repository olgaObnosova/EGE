# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 3 (10 класс)
# Программа № 42. Игра с фишками (одностороннее домино)
#

def gameOver( chain, fishSet ):
  if not chain:
    return not fishSet
  final = chain[-1]
  for fishka in fishSet:
    if final == fishka[0]:
      return False
  return True

def isWinPos( chain, fishSet ):
  if gameOver( chain, fishSet ):
    print( chain )
    return False
  if chain:
        final = chain[-1]
  else: final = ""
  for fishka in fishSet:
    if final == ""  or final == fishka[0]:
      newSet = fishSet[:]
      newSet.remove(fishka)
      if not isWinPos( chain+"-"+fishka, newSet ):
        return True
  return False

def header():
  for i in range(10):
    print( "{:2} ".format(1+(i%2)), end="" )
  print()
  print('-'*30)

fishSet = ["12", "14", "21", "22", "24", "41", "42", "44"]

chain = "44"
fishSet.remove(chain)
fishSet.remove("22")

print( "Start: ", chain )
header()
if isWinPos( chain, fishSet ):
  print( "Win!" )
else:
  print( "Lose..." )

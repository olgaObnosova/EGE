# -*- coding: utf-8
#
# Программа к учебному пособию
# К.Ю. Поляков. Программирование на языках Python и C++
# Часть 1 (8 класс)
# Программа № 3. Типы данных
#

lang = "Котлин"
print( type(lang) )

cost = 123
print( type(cost) )

dist = 45.678
print( type(dist) )

isGoodBoy = True
print( type(isGoodBoy) )

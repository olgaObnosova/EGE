# Автор В. Ганиев

a = [ int(x) for x in open('17-276.txt') ]

ans = []
for i in range(len(a)-2):
  if a[i+1]**2 == a[i]*a[i+2] and a[i+1]//a[i] != 1:
    d = max( a[i+1]//a[i], a[i]//a[i+1] )
    ans.append( d**2 )

print( len(ans), max(ans) )
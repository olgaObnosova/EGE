G = {}
G['А'] = ["Б", "Г", "Д"]
G['Б'] = ["В", "Г"]
G['В'] = ["Е", "З", "К"]
G['Г'] = ["В", "Е", "Ж"]
G['Д'] = ["Г"]
G['Е'] = ["Ж", "И", "К", "М"]
G['Ж'] = ["И"]
G['З'] = ["К", "Л"]
G['И'] = ["М"]
G['К'] = ["Л", "М", "Н"]
G['Л'] = ["Н"]
G['М'] = ["Н"]

def valid(way):
  return len(way) == 8

def allWays( fro, to, prev ):
  if fro == to:
    if valid(prev):
      print( prev )
    return
  for c in G[fro]:
    if not c in prev:
      allWays( c, to, prev+c )

allWays( "А", "Н", "A" )







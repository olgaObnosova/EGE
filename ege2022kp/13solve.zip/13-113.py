G = {
'А': "БГ",
'Б': "Д",
'В': "АБГДЖ",
'Г': "Ж",
'Д': "ЕЗК",
'Е': "ВИК",
'Ж': "Е",
'З': "К",
'И': "Ж",
'К': "И",
}

count = 0
def findPath( prevPath, nextTown, target ):
   global count
   path = prevPath + nextTown
   if nextTown == target and len(path) > 1:
      count += 1
      print( path )
      return
   for town in G[nextTown]:
      if not town in path or town == target:
        findPath( path, town, target )

findPath( "", 'Е', 'Е' )
print( count )
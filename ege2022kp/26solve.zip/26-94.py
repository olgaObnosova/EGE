with open('26-94.txt') as F:
  N, K = map( int, F.readline().split() )
  data = []
  for i in range(N):
    deck, row, place = map( int, F.readline().split() )
    data.append( (deck, row, place) )

data.sort()

def checkRow( mask ):
  global count, maxRow
  spaceCount = 0
  for i in range(2,K):
    if mask[i] == 0:
      spaceCount += 1
      if spaceCount >= 4:
        count += 1
        maxRow = max( maxRow, prevRow[1] )
        # print( prevRow, spaceCount, count )
        break
    else:
      spaceCount = 0

prevRow = data[0][0:2]
count = maxRow = 0
rowMask = [0]*(K+1)
for i in range(N):
  deck, row, place = data[i]
  if (deck, row) != prevRow:
    checkRow( rowMask )
    rowMask = [0]*(K+1)
  rowMask[place] = 1
  prevRow = (deck, row)

checkRow( rowMask )

print( maxRow, count )
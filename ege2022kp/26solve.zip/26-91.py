with open('26-91.txt') as F:
  N, D = map( int, F.readline().split() )
  data = [ int(F.readline()) for _ in range(N) ]

data.sort()
remainedWeight = sum( data )

i = 0
j = N-1
while i < j:
  while data[i] + data[j] > D:
    j -= 1
    if i >= j: break
  if i < j:
    remainedWeight -= data[i] + data[j]
  i += 1
  j -= 1

print( i, remainedWeight )






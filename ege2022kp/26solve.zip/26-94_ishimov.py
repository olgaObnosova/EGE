# Автор: М. Ишимов

f = open('26-94.txt')
n, k = map(int, f.readline().split())
a1 = [[] for x in range(100001)]
a2 = [[] for x in range(100001)]
ans = []

for i in range(n):
    e, r, m = map(int, f.readline().split())
    if e == 1:
        a1[r].append(m)
    elif e == 2:
        a2[r].append(m)

for r in range(100001):
    a1[r].sort()
    mas = sorted(a1[r])
    for m in range(1, len(mas)):
        if mas[m] - mas[m - 1] - 1 == 4:
            ans.append(r)

    a2[r].sort()
    mas = sorted(a2[r])
    for m in range(1, len(mas)):
        if mas[m] - mas[m - 1] - 1 == 4:
            ans.append(r)


print(max(ans), len(ans))